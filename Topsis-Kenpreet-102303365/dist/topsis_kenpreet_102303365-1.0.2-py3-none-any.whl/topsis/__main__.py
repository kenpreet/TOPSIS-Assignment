from .topsis import topsis_main

topsis_main()
